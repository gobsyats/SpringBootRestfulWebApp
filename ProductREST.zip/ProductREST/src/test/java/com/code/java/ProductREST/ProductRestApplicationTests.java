package com.code.java.ProductREST;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
